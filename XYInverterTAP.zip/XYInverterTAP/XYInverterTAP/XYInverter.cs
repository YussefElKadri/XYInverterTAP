﻿using System;
using System.IO;
using System.Text.RegularExpressions;

class ProcessaTAP
{
	public string ArquivosTAP(string pasta)
	{
		string outputDirectory = Path.Combine(pasta, "_Ajustados_XYIJG2G3");

		// Criar diretório de saída se não existir
		if (!Directory.Exists(outputDirectory))
		{
			Directory.CreateDirectory(outputDirectory);
		}

		// Obter todos os arquivos .tap no diretório
		string[] tapFiles = Directory.GetFiles(pasta, "*.TAP");

		foreach (string file in tapFiles)
		{
			ProcessFile(file, outputDirectory);
		}

		Console.WriteLine("Processamento concluído. Arquivos atualizados estão no diretório 'Processed'.");
		return pasta;
	}

	static void ProcessFile(string inputFilePath, string outputDirectory)
	{
		string outputFilePath = Path.Combine(outputDirectory, Path.GetFileName(inputFilePath));
		string[] lines = File.ReadAllLines(inputFilePath);

		for (int i = 0; i < lines.Length; i++)
		{
			// Ignorar a penúltima linha
			if (i != lines.Length - 2)
			{
				lines[i] = ProcessLine(lines[i]);
			}
		}

		File.WriteAllLines(outputFilePath, lines);
		Console.WriteLine($"Arquivo processado: {Path.GetFileName(inputFilePath)}");
	}

	static string ProcessLine(string line)
	{
		bool swapped = false;

		// Inverter X e Y, I e J
		string newLine = SwapXYIJ(line, ref swapped);

		// Trocar G2 por G3 ou G3 por G2 se houver inversão
		if (swapped && (newLine.Contains("G2") || newLine.Contains("G3")))
		{
			newLine = SwapG2G3(newLine);
		}

		return newLine;
	}

	static string SwapXYIJ(string line, ref bool swapped)
	{
		Regex regex = new Regex(@"([XYIJ])([-+]?\d*\.?\d+)");
		MatchCollection matches = regex.Matches(line);

		string xValue = null, yValue = null, iValue = null, jValue = null;

		foreach (Match match in matches)
		{
			string axis = match.Groups[1].Value;
			string value = match.Groups[2].Value;

			if (axis == "X") xValue = value;
			if (axis == "Y") yValue = value;
			if (axis == "I") iValue = value;
			if (axis == "J") jValue = value;
		}

		if (xValue != null && yValue != null)
		{
			line = Regex.Replace(line, @"X[-+]?\d*\.?\d+", $"X{yValue}");
			line = Regex.Replace(line, @"Y[-+]?\d*\.?\d+", $"Y{xValue}");
			swapped = true;
		}

		if (iValue != null && jValue != null)
		{
			line = Regex.Replace(line, @"I[-+]?\d*\.?\d+", $"I{jValue}");
			line = Regex.Replace(line, @"J[-+]?\d*\.?\d+", $"J{iValue}");
			swapped = true;
		}

		return line;
	}

	static string SwapG2G3(string line)
	{
		if (line.Contains("G2"))
		{
			line = line.Replace("G2", "G3");
		}
		else if (line.Contains("G3"))
		{
			line = line.Replace("G3", "G2");
		}
		return line;
	}
}

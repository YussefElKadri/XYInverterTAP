﻿using System;
using System.IO;
using System.Windows.Forms;

namespace LeituraEscritaArquivos
{
	internal class Program
	{
		static void Main(string[] args)
		{
			//CHAMAR("NomeCompletoApp" ; "NomeCompletoPastaSemEspaco\*.*")

			DateTime dataatual = DateTime.Now;
			DateTime datavencimento = new DateTime(year: 2050, 12, 31, 23, 59, 00);
			int comparativodata = DateTime.Compare(dataatual, datavencimento);
			ProcessaTAP novoprocessamento = new ProcessaTAP();

			if (comparativodata <= 0)
			{
				if (args.Length > 0)
				{
					for (int i = 0; i < args.Length; i++)
					{
						string somentepasta = Path.GetDirectoryName(args[i]);
						novoprocessamento.ArquivosTAP(somentepasta);
					}
				}
				else if (args.Length <= 0)
				{
					string pasta = Directory.GetCurrentDirectory();
					novoprocessamento.ArquivosTAP(pasta);
				}
			}
			else
			{
				MessageBox.Show("Sem licença!\nEntrar em contato com o Desenvolvedor - TopSystem\n(43) 9 9919-2981", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
		}
	}
}